import React from 'react';

import California from './california';

const Root = () => {
  return(
    <div>
      <California />
    </div>
  );
};

export default Root;
