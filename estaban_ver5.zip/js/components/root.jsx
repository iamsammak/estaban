import React from 'react';

import Estaban from './estaban';

const Root = () => {
  return(
    <div>
      <Estaban />
    </div>
  );
};

export default Root;
